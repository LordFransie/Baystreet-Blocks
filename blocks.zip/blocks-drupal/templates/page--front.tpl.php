<?php 
blocks_header($page); // Call Header 

blocks_front_page($page); // Call Front Page

blocks_footer($page); // Call Footer
?>

