<?php 

require_once(drupal_get_path('theme', 'blocks').'/includes/header.php');
require_once(drupal_get_path('theme', 'blocks').'/includes/front-page.php');
require_once(drupal_get_path('theme', 'blocks').'/includes/footer.php');

require_once(drupal_get_path('theme', 'blocks').'/includes/switch.php');
	
?>

